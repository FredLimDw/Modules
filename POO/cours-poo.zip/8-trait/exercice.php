<?php 


interface EtreVivant
{
    public function respirer(): string;
    public function dormir(): string;
    public function manger(): string;
    public function boire(): string;
}

interface Renseignement
{
    public function espece(): string;
    public function sexe(): string;
    public function age(): string;
}

trait Voler
{
    public function voler(): string 
    {
        return 'L\'animal peut voler';
    }
}

trait Pondre 
{
    public function pondre(): string
    {
        return 'L\'animal peut pondre';
    }

}

trait Vivipare 
{
    public function vivipare(): string
    {
        return 'L\'animal ne pond pas d\'oeufs';
    }
}

trait Quadrupede 
{
    public function quadrupede(): string
    {
        return 'L\'animal a 4 pattes';
    }
}

trait Ramper
{
    public function ramper(): string
    {
        return 'L\'animal peut ramper';
    }
}

trait Nager
{
    public function nager(): string
    {
        return 'L\'animal peut nager';
    }
}

trait Marcher 
{
    public function marcher(): string
    {
        return 'L\'animal peut marcher';
    }
}

class PoissonRouge implements EtreVivant, Renseignement
{
    use Pondre, Nager;

    public function respirer(): string
    {
        return 'Le poisson rouge respire';
    }

    public function dormir(): string
    {
        return 'Le poisson rouge dort';
    }

    public function manger(): string
    {
        return 'Le poisson rouge mange';
    }

    public function boire(): string
    {
        return 'Le poisson rouge boit';
    }

    public function espece(): string
    {
        return 'Le poisson rouge est d\'espèce poisson';
    }

    public function sexe(): string
    {
        return 'Le poisson rouge est de sexe masculin';
    }

    public function age(): string
    {
        return 'Le poisson rouge a 1 an';
    }

    public function afficherDetails(): string
    {
        return "<p>{$this->respirer()}</p>
                <p>{$this->dormir()}</p>
                <p>{$this->manger()}</p>
                <p>{$this->boire()}</p>
                <p>{$this->espece()}</p>
                <p>{$this->sexe()}</p>
                <p>{$this->age()}</p>
                <p>{$this->pondre()}</p>
                <p>{$this->nager()}</p>";
    }
}
$poissonRouge = new PoissonRouge();
echo $poissonRouge->afficherDetails();


class Chien implements EtreVivant, Renseignement
{
    use Vivipare, Nager, Marcher, Quadrupede;

    public function respirer(): string
    {
        return 'Le chien respire';
    }

    public function dormir(): string
    {
        return 'Le chien dort';
    }

    public function manger(): string
    {
        return 'Le chien mange';
    }

    public function boire(): string
    {
        return 'Le chien boit';
    }

    public function espece(): string
    {
        return 'Le chien est d\'espèce mammifère';
    }

    public function sexe(): string
    {
        return 'Le chien est de sexe masculin';
    }

    public function age(): string
    {
        return 'Le chien a 5 ans';
    }

    public function afficherDetails(): string
    {
        return "<p>{$this->respirer()}</p>
                <p>{$this->dormir()}</p>
                <p>{$this->manger()}</p>
                <p>{$this->boire()}</p>
                <p>{$this->espece()}</p>
                <p>{$this->sexe()}</p>
                <p>{$this->age()}</p>
                <p>{$this->marcher()}</p>
                <p>{$this->quadrupede()}</p>
                <p>{$this->vivipare()}</p>
                <p>{$this->nager()}</p>";
    }
}
$chien = new Chien();
echo $chien->afficherDetails();


/*

    Créer une interface EtreVivant 
        qui contiendra les méthodes :
            - respirer
            - dormir
            - manger
            - boire
    
    Créer une interface Renseignement 
        qui contiendra les méthodes :
            - espece
            - sexe
            - age 

    Créer un trait voler
        qui contiendra une méthode voler() qui retournera 'Cet animal peut voler'

    Créer un trait pondre
        qui contiendra une méthode pondre() qui retournera 'Cet animal peut pondre'

    Créer un trait vivipare 
        qui contiendra une méthode vivapare() qui retourne 'Cet animal ne pond pas d'oeufs'
    
    Créer un trait ramper 
        qui contiendra une méthode ramper() qui retournera 'Cet animal peut ramper'

    Créer un trait quadrupede
        qui contiendra une méthode quadrupede() qui retournera 'Cet animal a 4 pattes'
    
    Créer un trait nager
        qui contiendra une méthode nager() qui retounera 'Cet animal peut nager'

    Créer un trait marcher
        qui contiendra une méthode marcher() qui retournera 'Cet animal peut marcher'

    
    Créer des class : PoissonRouge, Baleine, Boa, Chien, Aigle

    Ces class doivent implémenter les 2 interfaces (à vous de remplir les méthodes)
    Importer les traits en fonction de l'animal

    Créer un objet pour chaque class et afficher les différents méthodes soit les unes après les autres sinon créer une méthode afficherDetails()



*/