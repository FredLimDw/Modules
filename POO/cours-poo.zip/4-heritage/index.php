<?php 

/*
    Une class peut hériter d'un autre class
    On peut les différentier en les appellant class mère et class fille
    Pour ça on utilise le terme extends

    Dans une class héritière (fille), on peut accéder aux informations de la class mère/parent qui ont la visibilité public ou protected

    Si le nom d'une méthode existe dans la class mère et la class fille, alors c'est celle de la fille qui sera prise en compte (écrasement de celle dans la mère)

    Une class peut hériter d'une class qui hérite également d'une autre class
    Exemple 
    Class A 
    Class B extends A
    Class C extends B

    Donc C hérite de B et de A

    Une class peut hériter que d'une seule class


*/
Class Animal 
{
    private $propertyPrivate = 'Property private';
    protected $propertyProtected = 'Property protected';
    public $propertyPublic = 'Property public';

    public function manger()
    {
        return 'je mange';
    }

    public function dormir()
    {
        return 'ZzZzzZZzz';
    }
}

// La class Chien (fille) hérite de tout ce qui se trouve dans la class Animal (mère)
Class Chien extends Animal
{
    public function aboyer()
    {
        
    }

    public function manger()
    {
        // surchargement
        return parent::manger() . ' un os';
    }
    

    public function getPropertyProtected()
    {
        return $this->propertyProtected;
    }

    // public function getPropertyPrivate()
    // {
    //     return $this->propertyPrivate;
    // }

}

Class Chiot extends Chien 
{

}

Class Chat extends Animal
{

    public function miauler()
    {
        
    }

    public function manger()
    {
        return parent::manger() . ' une souris';
    }

}


$chien1 = new Chien();
echo $chien1->propertyPublic;
echo '<br>';
//echo $chien1->getPropertyPrivate();
echo '<br>';
echo $chien1->getPropertyProtected();
echo '<br>';
echo $chien1->manger();

echo '<br>';
$chat1 = new Chat();
echo $chat1->dormir();

echo '<br>';
$chiot1 = new Chiot();
echo $chiot1->manger();


echo '<hr>';
echo '<hr>';
echo '<hr>';
// Héritage sans extends

Class A 
{
    public function bonjour(): string
    {
        return 'bonjour';
    }
}


Class B 
{
    public $a;

    public function __construct()
    {
        $this->a = new A();
    }

    public function recuperation()
    {
        return $this->a->bonjour();
    }
}

$b = new B();
echo $b->recuperation();
