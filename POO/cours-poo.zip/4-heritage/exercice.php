<?php 


class Vehicle 
{
    protected $marque;
    protected $modele;
    protected $vitesseMax;

    public function __construct(string $marque, string $modele, int $vitesseMax)
    {
        $this->marque = $marque;
        $this->modele = $modele;
        $this->vitesseMax = $vitesseMax;
    }

    public function afficherDetails(): string
    {
        return "<p>Marque : {$this->marque} </p>
                <p>Modèle :  {$this->modele} </p>
                <p>Vitesse Max : {$this->vitesseMax} </p>";
    }

    public function rouler(int $vitesse): string
    {
        if ($vitesse > $this->vitesseMax) {
            return '<h2>Impossible de rouler à cette vitesse, elle dépasse la vitesse maximale</h2>';
        } else {
            return '<h2>Le véhicule roule à ' . $vitesse . ' Km/h</h2>';
        }
        
        
    }

}

Class Voiture extends Vehicle
{
    private $nombreDePortes;

    public function __construct(string $marque, string $modele, int $vitesseMax, int $nombreDePortes)
    {
        parent::__construct($marque,$modele,$vitesseMax);
        $this->nombreDePortes = $nombreDePortes;
    }

    public function afficherDetails(): string
    {
        return parent::afficherDetails() . '<p>Nombre de portes : ' . $this->nombreDePortes . '</p>';
    }
}

Class Moto extends Vehicle
{
    const SPORT = 'Sport';
    const ROADSTER = 'Roadster';
    const CRUISER = 'Cruiser';

    private $typeMoto;

    public function __construct(string $marque, string $modele, int $vitesseMax, string $typeMoto)
    {
        parent::__construct($marque,$modele,$vitesseMax);
        $this->typeMoto = $typeMoto;
    }

    public function afficherDetails(): string
    {
        return parent::afficherDetails() . '<p>Type Moto : ' . $this->typeMoto . '</p>';
    }
}


$voiture1 = new Voiture('audi', 'a3', 250, 3);
echo $voiture1->afficherDetails();
echo $voiture1->rouler(270);

echo '<hr>';

$moto1 = new Moto('suzuki', 'gsxr', 280, Moto::CRUISER);
echo $moto1->afficherDetails();
echo $moto1->rouler(240);