<?php 

    abstract class VehiculeFr
    {
        const CARBURANT_ESSENCE = 'essence';
        const CARBURANT_DIESEL = 'diesel';

        final public function demarrer(): string
        {
            return 'Démarrage';
        }

        abstract public function carburant(): string;

        public function nombreDeTestObligatoire(): int 
        {
            return 100;
        }
        
        abstract public function afficherDetails(): string;
    }

    final class Peugeot extends VehiculeFr 
    {
        const MARQUE = 'Peugeot';
        public function carburant(): string
        {
            return 'essence';
            // return VehiculeFr::CARBURANT_ESSENCE;
        }

        public function nombreDeTestObligatoire(): int
        {
            return parent::nombreDeTestObligatoire() +  70;
        }

        public function afficherDetails(): string
        {
            return "<p>{$this->demarrer()}</p>
                    <p>{$this->carburant()}</p>
                    <p>{$this->nombreDeTestObligatoire()}</p>";
        }
    }

    final class Renault extends VehiculeFr 
    {
        const MARQUE = 'Renault';
        public function carburant(): string
        {
            return 'diesel';
            // return VehiculeFr::CARBURANT_DIESEL;
        }

        public function nombreDeTestObligatoire(): int
        {
            return parent::nombreDeTestObligatoire() + 30;
        }

        public function afficherDetails(): string
        {
            return "<p>{$this->demarrer()}</p>
                    <p>{$this->carburant()}</p>
                    <p>{$this->nombreDeTestObligatoire()}</p>";
        }
    }


    $peugeot1 = new Peugeot();
    // echo $peugeot1->demarrer();
    // echo '<br>';
    // echo $peugeot1->carburant();
    // echo '<br>';
    // echo $peugeot1->nombreDeTestObligatoire();
    // echo '<hr>';
    echo $peugeot1->afficherDetails();


    $renault1 = new Renault();
    // echo $renault1->demarrer();
    // echo '<br>';
    // echo $renault1->carburant();
    // echo '<br>';
    // echo $renault1->nombreDeTestObligatoire();
    echo $renault1->afficherDetails();
    /*
        Créer une class VehiculeFr qui ne peut pas être instanciée 
        Dans cette class :
            - créer une méthode public demarrer() qui retournera 'demarrage' (string), cette méthode ne pourra pas être modifiable
            - créer une méthode public carburant() qui devra obligatoire est déclarée dans les class enfant (Peugeot et Renault)
            - créer une méthode public nombreDeTestObligatoire() qui retournera 100 (integer)


        Créer une class Peugeot qui va hériter de VehiculeFr et qui ne peut pas se faire hériter
        Dans cette class :
            - Le carburant de peugeot est de l'essence (string)
            - Le nombre de test obligatoire chez peugeot est de 170

        Créer une class Renault qui va hériter de VehiculeFr et qui ne peut pas se faire hériter
        Dans cette class :
            - Le carburant de renault est de le diesel (string)
            - Le nombre de test obligatoire chez renault est de 130


        ----------------------------------------------------------
        Créer un objet peugeot et un objet renault
        afficher pour chacun d'eux le démarrage, le carburant et le nombre de test obligatoire
    */