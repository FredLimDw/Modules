<?php 

// Connexion à une base de données

$pdo = new PDO(
    'mysql:host=localhost; dbname=pdopoo', // serveur + nom de la base de données
    'root', // identifiant
    '', // mot de passe
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING,
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ] // tableau des options
);

// echo '<pre>';
// echo print_r(get_class_methods($pdo));
// echo '</pre>';



// Array
// (
//     [0] => __construct
//     [1] => beginTransaction
//     [2] => commit
//     [3] => errorCode
//     [4] => errorInfo
//     [5] => exec (INSERT INTO UPDATE DELETE)
//     [6] => getAttribute
//     [7] => getAvailableDrivers
//     [8] => inTransaction
//     [9] => lastInsertId
//     [10] => prepare (SELECT INSERT INTO UPDATE DELETE) ---------- 1e étape
//     [11] => query  (SELECT)
//     [12] => quote
//     [13] => rollBack
//     [14] => setAttribute
// )

/*

    Il existe 4 requêtes

    SELECT
    INSERT INTO
    UPDATE
    DELETE


    Il y a une requête qui retourne un jeu de résultats (SELECT) => méthode query()
    et il y a 3 requêtes qui ne retournent rien (INSERT INTO UPDATE DELETE) => méthode exec()

*/


 // $pdo->exec('INSERT INTO produit (titre,prix) VALUES("bague en or", 500)');


 $pdoStatement = $pdo->query('SELECT * FROM produit');

// quand on utilise la méthode query, ce qui est retourné est un objet de la class PDOStatement


echo '<pre>';
echo print_r(get_class_methods($pdoStatement));
echo '</pre>';


// Array
// (
//     [0] => bindColumn 
//     [1] => bindParam ---------- 2e étape (avec variable)
//     [2] => bindValue ---------- 1e étape
//     [3] => closeCursor
//     [4] => columnCount
//     [5] => debugDumpParams
//     [6] => errorCode
//     [7] => errorInfo
//     [8] => execute ---------- 3e étape
//     [9] => fetch       Récupération d'une ligne
//     [10] => fetchAll   Récupération de plusieurs lignes
//     [11] => fetchColumn
//     [12] => fetchObject
//     [13] => getAttribute
//     [14] => getColumnMeta
//     [15] => nextRowset
//     [16] => rowCount
//     [17] => setAttribute
//     [18] => setFetchMode
//     [19] => getIterator
// )
// echo '<pre>';
// print_r($pdoStatement->getColumnMeta(1));
// echo '</pre>';


echo '<pre>';
print_r($pdoStatement->fetchAll());
echo '</pre>';



// Méthode Prepare()

// 1e étape : Préparation de la requête
$pdoStatement = $pdo->prepare('SELECT * FROM produit WHERE id = :idMarqueur');


// 2e étape : Associer les marqueurs à leurs valeurs et à leurs types
$id = 3;
$pdoStatement->bindParam(':idMarqueur', $id, PDO::PARAM_INT);


// 3e étape : Exécuter la requête de préparation
$pdoStatement->execute();


echo '<pre>';
print_r($pdoStatement->fetch());
echo '</pre>';