<?php 

class Maison 
{
    private static $nbPiece = 7;
    public static $espaceTerrain = 500;
    public $couleur = 'blanc';
    const HAUTEUR = 10;
    private $nbPorte = 10;

    public static function getNbPiece(): int
    {
        return self::$nbPiece;
    }

    public function getNbPorte(): int 
    {
        return $this->nbPorte;
    }
}

$maison = new Maison();
echo 'La couleur de la maison est ' . $maison->couleur;
echo '<br>';
echo 'Le nombre de portes dans la maison est ' . $maison->getNbPorte();
echo '<br>';
echo 'L\'espace du terrain est de ' . Maison::$espaceTerrain;
echo '<br>';
echo 'La hauteur de la maison est ' . Maison::HAUTEUR;
echo '<br>';
echo 'Le nombre de pièce dans la maison est ' . Maison::getNbPiece();




/*
    depuis l'objet on accéde aux informations (public) et NON STATIC

    depuis la class on accéde aux informations STATIC et aux constantes
    Une class s'écrit toujours avec la première lettre en majuscule

    les syntaxes sont :
    CLASS::$propriété
    CLASS::méthode()
    CLASS::CONSTANTE (les constantes s'écrivent toujours en majuscule)

    $this permet de rechercher dans l'objet ($this fait référence à un objet de la class)
    self:: permet de rechercher dans la class (self:: fait référence à la class elle-même)

*/