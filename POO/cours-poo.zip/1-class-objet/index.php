<?php

/*
    Une class est un regroupement d'informations, comprenant :
        - propriétés (variables)
        - méthodes (fonctions)
        - constantes

    le contenu de la class aborde le même sujet
    exemple : la class PDO aborde le sujet de la base de données
              la class DateTime aborde le sujet de la date et le temps

    On n'utilise pas directement la class, celle-ci est un modèle
    on génère une instance/objet de la class (un exemplaire)
    On peut créer autant d'objets qu'on 
    un objet hérite de toutes les infos de la class 

    Pour générer la syntaxe est avec le mot-clé 'new'
    exemple : $objet = new Class

    Les informations (propriétés/méthodes) ont une visibilité :
        private
        protected
        public

        on distingue 3 'localisations' : 
            - dans la class
            - dans la class héritière
            - dans l'objet

    la visibilité private est accessible que depuis la class
    la visibilité protected est accessible dans la class et les class héritières
    la visibilité public est accessible dans la class, les class héritières et les objets
*/

class Voiture 
{
    public $marque;
    private $carburant = 'essence';

    public function demarrage(){
        return 'voiture allumée';
    }

    private function turbo() {
        return 'turbo';
    }

    public function info(){
        return 'la marque du véhicule est ' . $this->carburant;
        // $this sera étudié dans un prochain chapitre
    }
}

$voiture1 = new Voiture();

// echo $voiture1; // on ne peut pas afficher un objet sur le navigateur

// affectation
$voiture1->marque = 'audi';

// affichage
echo 'la voiture 1 est de la marque ' . $voiture1->marque;

// echo $voiture1->carburant;// on  ne peut pas accéder à une propriété privée depuis l'objet

echo '<br>';

echo $voiture1->info();



