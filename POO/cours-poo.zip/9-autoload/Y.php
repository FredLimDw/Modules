<?php 

class Y 
{
    public function __construct()
    {
        echo '<p>Instanciation d\'un objet issu de la class Y</p>';
    }
}