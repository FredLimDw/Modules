<?php 


// require_once('X.php');
// require_once('Y.php');
// require_once('Z.php');

require_once('autoload.php');


$x = new X();
$y = new Y();
$z = new Z();