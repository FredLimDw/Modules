<?php 

function inclusionAutomatique($nomDeLaClass)
{
    require_once($nomDeLaClass . '.php');
    echo '<p>On est passé par la fonction inclusionAutomatique()</p>';
}

spl_autoload_register('inclusionAutomatique');
/*
     la fonction prédéfinie PHP spl_autoload_register() est executée automatiquement à chaque fois qu'il y a le mot-clé 'new' dans le code (Rappel : le mot-clé 'new' permet de générer un objet, le terme qui suit le new est le nom de la class)

     L'objectif de la fonctionspl_autoload_register() est d'appeler une autre fonction, c'est le nom (str) de cette dernière qui doit être défini comme argument

*/