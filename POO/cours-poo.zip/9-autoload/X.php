<?php 

class X 
{
    public function __construct()
    {
        echo '<p>Instanciation d\'un objet issu de la class X</p>';
    }
}