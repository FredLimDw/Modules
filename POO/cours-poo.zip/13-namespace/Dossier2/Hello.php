<?php 

namespace Dossier2;

class Hello 
{
    public function __construct()
    {
        echo '<p>Je suis un objet de la class Hello du dossier 2</p>';
    }
}