<?php 

namespace Dossier1;

class Hello 
{
    public function __construct()
    {
        echo '<p>Je suis un objet de la class Hello du dossier 1</p>';
    }
}