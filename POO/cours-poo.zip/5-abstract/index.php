<?php 

abstract class Individu
{
    public function manger()
    {
    }

    public function boire()
    {   
    }

    public function dormir()
    { 
    }

    abstract public function prenom();
}

class Homme extends Individu
{
    public function prenom()
    {
    }
}

class Femme extends Individu
{
    public function prenom()
    {
    }
}

$individu = new Individu();

/*
    Une class abstract ne peut pas être instanciée (on ne peut pas créer d'objet issu de cette class)
    Une class abstract peut contenir des méthodes abstract, cependant elles sont déclarées sans contenu c'est-à-dire sans accolade : abstract public function nomFunction();
    l'intérêt est que les class enfants ont l'obligation de déclarer cette méthode abstract
    Attention une méthode abstract ne peut être que dans une class abstract
    Une class abstract peut contenir des méthodes normales

*/