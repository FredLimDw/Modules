<?php 

// class Etudiant 
// {
//     public $prenom;
//     public $nom;
// }

// $etudiant1 = new Etudiant();
// $etudiant1->prenom = 'jean';
// $etudiant1->nom = 'bal';

// echo 'l\'étudiant 1 s\'appelle ' . $etudiant1->prenom . ' ' . $etudiant1->nom;

class Etudiant
{
    private $prenom;
    private $nom;

    /*
        Il existe des méthodes magiques, elles sont reconnaissables par la syntaxe __nomMethodes
        elles commençent par 2 underscores.
        la méthode __construct est exécutée lors de la création des objets
        elle n'est pas obligatoire et il ne peut y en avoir qu'une
    */
    public function __construct(string $prenom = null, string $nom = null)
    {
       $this->prenom = $prenom;
       $this->nom = $nom; 
    }


    /**
     * getPrenom() permet d'afficher la valeur de la propriété prenom
     *
     * @return string
     */
    public function getPrenom() :string
    {
        return $this->prenom;
    }
    
    /**
     *  setPrenom() permet d'attribuer une valeur à la propriété prenom
     *
     * @param  mixed $argumentPrenom
     * @return void
     */
    public function setPrenom(string $argumentPrenom) :void
    {
        $this->prenom = $argumentPrenom; 
    }

    
    /**
     * getNom
     *
     * @return string
     */
    public function getNom(): string
    {
        return $this->nom;
    }
    
    /**
     * setNom
     *
     * @param  mixed $nom
     * @return void
     */
    public function setNom(string $nom) :void
    {
        $this->nom = $nom;
    }

    public function info(): string
    {
        return 'L\'étudiant s\'appelle ' .$this->prenom . ' ' . $this->nom;
    }
}

$etudiant1 = new Etudiant();
$etudiant1->setPrenom('jean');
// echo $etudiant1->getPrenom();
$etudiant1->setNom('brasse');
// echo $etudiant1->getNom();

echo $etudiant1->info();

echo '<br>';

$etudiant2 = new Etudiant('Paul', 'Icier');
// $etudiant2->setPrenom('louis');

echo $etudiant2->info();

echo '<br>';



$etudiant3 = new Etudiant('Marc', 'Assin');

echo $etudiant3->info();


/*
    $objet->propriete 
    $objet->methode()


    les propriétés prenom et nom sont de visibilité privée, autrement dit, elles ne sont qu'accessible que depuis la class elle-même

    Pour pouvoir afficher ou attribuer des valeurs à ses propriétés depuis l'objet, on utilisera des getters et des setteurs

    getteur : afficher
    setteur : attribuer


    le terme $this fait office de la class elle-même


    // comment bien écrire une méthode 
        - commenter
        - nom explicite (de préférence en anglais)
        - typer
        - indenter
*/