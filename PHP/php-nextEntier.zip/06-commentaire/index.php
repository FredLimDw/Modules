<!-- Réaliser un système de commentaire :

1. Création de la base de données
	Création de la table (id_commentaire, pseudo, message, date_heure_message)

2. Connexion à la BDD

3. Création du formulaire permettant de laisser son pseudo et son message

4. Récupération des informations et enregistrement dans la base de données

5. Affichage des messages sur la page

-->

<?php

// Je me connecte à la base de données :
$pdo = new PDO('mysql:host=localhost;dbname=dialogue', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
// Je vérifie :
// var_dump($pdo);

// Si le formulaire a été posté :
if($_POST) {
	// echo 'test';

	// Je gère le soucis d'apostrophe :
	$_POST['message'] = addslashes($_POST['message']);
	$_POST['pseudo'] = addslashes($_POST['pseudo']);

	$pdo->exec("INSERT INTO commentaire (pseudo, message, date_heure_message) VALUES ('$_POST[pseudo]', '$_POST[message]', NOW())");
}

// On affiche les messages de la base :
$r = $pdo->query('SELECT * FROM commentaire');
while($commentaire = $r->fetch(PDO::FETCH_ASSOC)) {
	echo $commentaire['pseudo'] . ' : ' . $commentaire['message'] . '<br>';
}

?>

<hr>

<form method="post">
	<input type="text" name="pseudo" placeholder="Pseudo">
	<textarea name="message" placeholder="Commentaire"></textarea>
	<input type="submit" value="Poster">
</form>