<?php

// Je garde la session ouverte :
session_start();

// Je récupère les infos que je veux :
echo $_SESSION['prenom'];



?>