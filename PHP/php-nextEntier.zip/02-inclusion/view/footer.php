<footer>
			<p>&copy; <?php echo date('Y'); ?> - Next Formation</p>
		</footer>