<?php

// Je me connecte à la base de données :
$pdo = new PDO('mysql:host=localhost;dbname=entreprise', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

// host : serveur
// dbname : nom de la base
// root : utilisateur
// '' : mot de passe 
// PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING : permet d'afficher les erreurs SQL
// PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' : pour encoder les échanges avec la base en UTF8

// Vérification :
// var_dump($pdo);

// J'insère un nouvel employés :
// $pdo->exec('INSERT INTO employes (prenom, nom, sexe, service, date_embauche, salaire) VALUES ("Alexandre", "Dupond", "m", "commercial", "2024-08-30", 2000)');

// Je modifie un employés :
// $pdo->exec('UPDATE employes SET prenom = "Alex" WHERE id_employes = 991');

// Je supprime un employés :
// $pdo->exec('DELETE FROM employes WHERE id_employes = 991');


// Afficher un employé sur la page :
// Je créé une variable pour stocker toutes les infos de Stephanie :
$r = $pdo->query('SELECT * FROM employes WHERE id_employes = 990');
// Je stock dans la variable $employe, les informations stocké dans $r sous forme d'array :
$employe = $r->fetch(PDO::FETCH_ASSOC);
// On l'affiche :
print_r($employe);
echo '<br>';
// Exercice :
// Afficher le prenom et le nom de l'employé :
echo $employe['prenom'] . ' ' . $employe['nom'] . '<br>';


// Le faire avec toute la table :
$r = $pdo->query('SELECT * FROM employes');
// Je fais une boucle pour tous les afficher :
while($employe = $r->fetch(PDO::FETCH_ASSOC)) {
	// print_r($employe);
	echo $employe['prenom'] . ' ' . $employe['nom'] . '<br>';
}

?>