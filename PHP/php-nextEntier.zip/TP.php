

Créer une système d'ajout de livres dans un répertoire.

1. Créer une BDD bibliothèque
	Table : livre (id_livre, titre, auteur)

2. Créer un formulaire d'ajout de livre

3. On enregistre en base les livres ajoutés

4. On affiche un tableau HTML qui récapitule les livres présent en base

