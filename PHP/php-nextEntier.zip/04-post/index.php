<form method="post">
	<label>Prenom</label>
	<input type="text" name="prenom">
	<br><br>
	<label>Description</label>
	<textarea name="description"></textarea>
	<br><br>
	<input type="submit" value="Poster">
</form>

<?php
// Si le formulaire à été posté :
if($_POST) {
	echo '<div id="fond">';
	echo $_POST['prenom'] . '<br>';
	echo $_POST['description'] . '<br>';
	echo '</div>';
}

?>