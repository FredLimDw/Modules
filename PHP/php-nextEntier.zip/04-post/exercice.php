<!-- 
Créer un formulaire d'inscription prenant en compte les champs :
-Nom
-Prenom
-Adresse mail
-Mot de passe

Quand on valide le formulaire, il y a une liste HTML qui apparait pour récapituler les champs renseignés.

Et le formulaire disparait.
-->

<?php

if(isset($_POST['validation'])) {
	echo '<p>Votre inscription est validée. Voici le récapitulatif de vos informations :</p>';
	echo '<ul>';
		echo '<li>Nom : ' . $_POST['nom'] . '</li>';
		echo '<li>Prénom : ' . $_POST['prenom'] . '</li>';
		echo '<li>Adresse mail : ' . $_POST['email'] . '</li>';
		echo '<li>Mot de passe : ' . password_hash($_POST['password'], PASSWORD_DEFAULT) . '</li>';
	echo '</ul>';
} else {

?>

<form method="post">
	<input type="text" name="nom" placeholder="Nom">
	<br><br>
	<input type="text" name="prenom" placeholder="Prénom">
	<br><br>
	<input type="email" name="email" placeholder="Adresse mail">
	<br><br>
	<input type="password" name="password" placeholder="Mot de passe">
	<br><br>
	<input type="submit" value="S'inscrire" name="validation">
</form>

<?php

}

?>