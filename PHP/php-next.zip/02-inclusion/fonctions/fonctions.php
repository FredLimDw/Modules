<?php

function bonjour() {
	echo '<span>Bonjour</span><br>';
}

?>