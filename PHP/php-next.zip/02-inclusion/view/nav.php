<nav>
			<a href="index.php">Accueil</a>
			<a href="apropos.php">A propos</a>
			<a href="contact.php">Contact</a>
		</nav>