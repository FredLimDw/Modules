<h2>01. Affichage</h2>
<!-- Commentaire HTML -->

<?php
/*Ouverture du PHP*/

// Commentaire d'une seule ligne
/* Commentaire
de
plusieurs
lignes */

// J'affiche la chaine de caractère Bonjour :
echo 'Bonjour';

// On peut écrire du HTML :
echo '<br>';
echo 'Bienvenue';

/*Fermeture du PHP*/
?>

<p>Voici du texte</p>

<?php
// Nouvelle zone de PHP
?>

<hr>

<h2>02. Variables : types, déclaration, affectation</h2>

<?php

// Créer et affecter une variable :
$prenom = 'Richard';
// J'affiche la valeur de la variable :
echo $prenom;

echo '<br>';

$a = 127;
echo gettype($a);

echo '<br>';

$b = 1.5;
echo gettype($b);

echo '<br>';

$c = 'du texte';
echo gettype($c);

echo '<br>';

$d = '127';
echo gettype($d);

echo '<br>';

$e = TRUE;
echo gettype($e);

echo '<br>';

// On peut modifier la valeur d'une variable :
$prenom = 'Amin';
echo $prenom;

?>

<hr>

<h2>03. Concaténation</h2>

<?php

// On peut afficher plusieurs chaine de caractères dans une seule instruction echo grâce à la concaténation :
echo 'Bonjour ' . 'tout le monde' . '<br>';

echo 'Bonjour ' . $prenom . ', comment ça va ?<br>';

// Ajouter une valeur à une variable :
$prenom = 'Abdelkader';
$prenom .= ' Bakouche'; 

echo $prenom;

?>

<hr>

<h2>04. Guillemets et Quotes</h2>

<?php

$message1 = "aujourd'hui";
$message2 = 'aujourd\'hui';

echo $message1 . '<br>' . $message2 . '<br>';

// Dans des guillemets la variable est interprêtée :
echo "Bonjour comment ça va $message1 ? <br>";
// Dans des quotes la variable n'est pas interprêtée :
echo 'Bonjour comment ça va $message1 ? <br>';
// Il faut concaténer :
echo 'Bonjour comment ça va ' . $message1 . ' ? <br>';

?>

<hr>

<h2>05. Constantes</h2>

<?php

// Definir une constante :
define('CAPITALE', 'Paris');
// On l'affiche :
echo CAPITALE;

// On ne peut pas modifier la valeur d'une constante :
// define('CAPITALE', 'Lyon');
// echo CAPITALE;

echo '<br>';

// Constantes prédéfinies :
echo __FILE__;
echo '<br>';
echo __LINE__;

?>

<hr>

<h2>06. Opérateurs Arithmétiques</h2>

<?php

$a = 10;
$b = 2;

// Nous pouvons faire des opérations en PHP :
echo $a + $b . '<br>';
echo $a - $b . '<br>';
echo $a * $b . '<br>';
echo $a / $b . '<br>';

// On peut ajouter une valeur dans une variable :
$a += $b;
echo $a;

?>

<hr>

<h2>07. Structures conditionnelles</h2>

<?php

$a = 10;
$b = 5;
$c = 2;

// Si A est supérieur à B alors j'affiche du texte :
if($a > $b) {
	// Tout le code entre les accolades est executé uniquement si la condition est valide
	echo 'A est bien supérieur à B<br>';
} else {
	echo 'B est supérieur à A<br>';
}

// ET (Les deux conditions doivent être valides) :
// Si A est supérieur à B ET si B est supérieur à C :
if($a > $b && $b > $c) {
	echo 'A est supérieur à B ET B est superieur à C<br>';
}

// On peut mettre une condition dans une condition :
if($a > $b) {
	echo 'Première condition valide<br>';
	if($b < $c) {
		echo 'Deuxième condition valide<br>';
	}
}

// OU (Une seule des deux conditions minimum suffit pour rendre la condition valide) :
// Si A est égal à 9 OU ALORS si B est supérieur à C :
if($a == 9 || $b > $c) {
	echo 'A est égal 9 ou B est supérieur à C<br>';
}

// Condition exclusive (Une seule des deux conditions doit être valide) :
// Si A est égal à 10 OU B supérieur à C :
if($a == 10 XOR $b > $c) {
	echo 'A est égal à 10 OU B est supérieur à C<br>';
}

// Si A est egal à 8
// Sinon si A est différent de 10
// Sinon...
if($a == 8) {
	echo 'A est égal à 8<br>';
} else if ($a != 10) {
	echo 'A est différent de 10<br>';
} else {
	echo 'Condition par défaut<br>';
}

// Vérifier l'existance d'une variable :
$var = 'qqchose';
// Si la variable $var existe :
if(isset($var)) {
	echo 'oui<br>';
} else {
	echo 'non<br>';
}

// Différence entre le double égal et le triple égal :
$vara = 1;
$varb = '1';

// Est-ce que $vara à la même valeur que $varb ?
if($vara == $varb) {
	echo 'Les variables ont la même valeur<br>';
}

// Est-ce que $vara et $varb ont la même valeur et le même type ?
if($vara === $varb) {
	echo 'Les variables ont la même valeur et le même type<br>';
} else {
	echo 'Les variables ne correspondent pas<br>';
}

// = Donner une valeur à une variable
// == Comparer les valeurs
// === Comparer les valeurs et le type 


// Condition Switch :
$couleur = 'rose';
// Je vérifie la valeur de $couleur :
switch($couleur) {
	// 1er cas : Si c'est du bleu
	case 'bleu' :
		echo 'Vous aimez le bleu<br>';
	break;
	// 2eme cas :
	case 'rouge' :
		echo 'Vous aimez le rouge<br>';
	break;
	// 3eme cas :
	case 'vert' :
		echo 'Vous aimez le vert<br>';
	break;
	// 4eme cas :
	case 'jaune' :
		echo 'Vous aimez le jaune<br>';
	break;
	// Cas par défaut :
	default :
		echo 'Vous n\'aimez pas les couleurs testée<br>';
	break;
}

?>

<hr>

<h2>08. Fonctions prédéfinies</h2>

<?php

$phrase = 'texte1 texte2 texte3 texte4 texte5 texte6 texte7 texte8 texte9';
echo $phrase . '<br>';

// Fonction qui permet de voir le nombre de caractères d'une chaine :
echo iconv_strlen($phrase) . '<br>';

// Exemple sur le nombre de caractère d'un mot de passe :
$password = 'fdhgdfghfdghgfshgfshsgfhsfgh';
$nbCaractere = iconv_strlen($password);

if($nbCaractere < 10) {
	echo 'Mot de passe trop petit';
}

// Afficher le début d'une chaine :
echo substr($phrase, 0, 27) . '...<br>';

// Afficher la date actuelle :
echo date('d-m-y') . '<br>';

?>

<hr>

<h2>09. Fonctions Utilisateurs</h2>

<?php

// Je crée une fonction :
function bonjour() {
	echo 'Bonjour<br>';
}

// Je l'execute :
bonjour();


// Fonction avec un paramètre :
function bonjour2($x) {
	echo 'Bonjour ' . $x . '<br>';
}

bonjour2('Richard');
bonjour2('Anisse');


// Variable locale (qui est créée à l'intérieur d'une fonction) :
function jourSemaine() {
	$jour = 'mercredi<br>';
	return $jour;
}

// Ça ne marche pas car la variable est dans la fonction :
// jourSemaine();
// echo $jour;

// Ça marche car j'affiche ce que la fonction me retourne :
echo jourSemaine();

$r = jourSemaine();
echo $r;


// Variable globale (qui est créée en dehors d'une fonction) :
$pays = 'France';

function affichagePays() {
	// On va récupérer la variable dans l'espace global :
	global $pays;
	echo $pays;
}

affichagePays();

?>

<hr>

<h2>10. Structure itérative (boucle)</h2>

<?php

// WHILE :
$i = 0;
while($i <= 5) {
	echo 'Bonjour' . $i . '---';
	$i++;
}

echo '<br>';

// Refaire la même boucle, sans afficher les derniers tirets :
$i = 0;
while($i <= 5) {
	if($i < 5) {
		echo 'Bonjour' . $i . '---';
		$i++;
	} else {
		echo 'Bonjour' . $i;
		$i++;
	}
}

echo '<br>';

// FOR :
for($i = 0; $i <= 5; $i++) {
	echo 'Tour numéro : ' . $i . '<br>';
}

// Exercice : Faire un select qui affiche les années d'aujourd'hui à 1920
echo '<select>';
	for($i = date('Y'); $i >= 1920; $i--) {
		echo '<option>' . $i . '</option>';
	}
echo '</select>';

?>

<select>
	<?php
	for($i = date('Y'); $i >= 1920; $i--) {
		echo '<option>' . $i . '</option>';
	}
	?>
</select>

<?php
// Exercice : Créer un tableau de 10 lignes (tr) et 10 colonnes (td) par ligne numéroté de 00 à 99 :
echo '<table border="1">';
	for($ligne = 0; $ligne < 10; $ligne++) {
		echo '<tr>';
			for($collone = 0; $collone < 10; $collone++) {
				echo '<td>' . $ligne . $collone . '</td>';
			}
		echo '</tr>';
	}
echo '</table>';
?>

<hr>

<h2>11. Inclusions de fichiers</h2>

<?php

// INCLUDE :
include('fichier.php');
// S'il y a une erreur dans l'appel du fichier, le reste de la page continu de charger

// REQUIRE :
require('fichier.php');
// S'il y a une erreur dans l'appel du fichier, le reste de la page ne se charge pas

echo 'Suite du code<br>';

?>

<hr>

<h2>12. Array</h2>

<?php

// Je crée un array :
$liste = array('rouge', 'bleu', 'orange', 'jaune', 'rose');

// Afficher l'array :
print_r($liste);
echo '<br>';
var_dump($liste);
echo '<br>';

// Afficher un seul élément :
echo $liste[2] . '<br>';


// Autre manière pour créer un array :
$tab[] = 'France';
$tab[] = 'Italie';
$tab[] = 'Espagne';
$tab[] = 'Angleterre';

print_r($tab);
echo '<br>';

// 3ème manière :
$test = ['France', 'Italie'];
var_dump($test);
echo '<br>';

// Boucle foreach pour parcourir un array :
foreach($tab as $indice => $valeur) {
	echo $indice . ' : ' . $valeur . '<br>';
}

// Fonction pour voir le nombre d'éléments dans un array :
echo count($tab) . '<br>';


// Tableau multidimensionnel :
$tab_multi = array(0 => array('prenom' => 'Richard', 'nom' => 'Bonnegent'), 1 => array('prenom' => 'Abdelkader', 'nom' => 'Bakouche'));

var_dump($tab_multi);

// Afficher seulement le prenom de Richard :
echo $tab_multi[0]['prenom'];

?>