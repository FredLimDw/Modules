<h1>Index</h1>
<hr>
<a href="page2.php?produit=jean&couleur=bleu&prix=10">Page 2</a>

<!-- Créer 3 liens pour aller sur la page qui présente :
-Un T-shirt rouge à 14€
-Un pantalon blanc à 25€
-Un chapeau violet à 30€ 

Sur la page 2, afficher la phrase :
Vous avez choisi le ... de couleur ... au prix de ...€

S'il n'y a pas d'info dans l'URL, on affiche la phrase :
Aucun produit sélectionné
-->

<a href="page2.php?produit=T-shirt&couleur=rouge&prix=14">T-shirt</a>
<a href="page2.php?produit=pantalon&couleur=blanc&prix=25">Pantalon</a>
<a href="page2.php?produit=chapeau&couleur=violet&prix=30">Chapeau</a>
<a href="page2.php">Aucun produit</a>