/* Le total des paiements effectués de chaque client (numéro, nom et pays) américain, allemand ou français de plus de 50000$ trié par pays puis par total des paiements décroissant */
/* RESULTAT ==> 38 lignes / 146 / 130305.35 */



/* Le montant total de chaque commande (numéro et date) des clients New-Yorkais (nom) trié par nom du client puis par date de commande */
/* RESULTAT ==> 16 lignes / Classic Legends / 10115 / 21665.98 */
